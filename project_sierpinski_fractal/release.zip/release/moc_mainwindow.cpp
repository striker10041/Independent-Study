/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "E:/fractals/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[25];
    char stringdata0[425];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 16), // "signalMousePress"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 18), // "signalMouseRelease"
QT_MOC_LITERAL(4, 48, 15), // "signalMouseMove"
QT_MOC_LITERAL(5, 64, 11), // "signalWhell"
QT_MOC_LITERAL(6, 76, 14), // "signalAddPoins"
QT_MOC_LITERAL(7, 91, 11), // "signalColor"
QT_MOC_LITERAL(8, 103, 14), // "slotMousePress"
QT_MOC_LITERAL(9, 118, 16), // "slotMouseRelease"
QT_MOC_LITERAL(10, 135, 13), // "slotMouseMove"
QT_MOC_LITERAL(11, 149, 9), // "slotWhell"
QT_MOC_LITERAL(12, 159, 13), // "slotAddPoints"
QT_MOC_LITERAL(13, 173, 9), // "slotColor"
QT_MOC_LITERAL(14, 183, 24), // "on_cb_nAuto_stateChanged"
QT_MOC_LITERAL(15, 208, 4), // "arg1"
QT_MOC_LITERAL(16, 213, 20), // "on_sb_n_valueChanged"
QT_MOC_LITERAL(17, 234, 19), // "on_pb_clear_clicked"
QT_MOC_LITERAL(18, 254, 20), // "on_pb_saveAs_clicked"
QT_MOC_LITERAL(19, 275, 20), // "on_pb_update_clicked"
QT_MOC_LITERAL(20, 296, 30), // "on_cb_choosePoint_stateChanged"
QT_MOC_LITERAL(21, 327, 23), // "on_cb_fill_stateChanged"
QT_MOC_LITERAL(22, 351, 27), // "on_cb_showGrid_stateChanged"
QT_MOC_LITERAL(23, 379, 23), // "on_cb_setZ_stateChanged"
QT_MOC_LITERAL(24, 403, 21) // "on_pb_default_clicked"

    },
    "MainWindow\0signalMousePress\0\0"
    "signalMouseRelease\0signalMouseMove\0"
    "signalWhell\0signalAddPoins\0signalColor\0"
    "slotMousePress\0slotMouseRelease\0"
    "slotMouseMove\0slotWhell\0slotAddPoints\0"
    "slotColor\0on_cb_nAuto_stateChanged\0"
    "arg1\0on_sb_n_valueChanged\0on_pb_clear_clicked\0"
    "on_pb_saveAs_clicked\0on_pb_update_clicked\0"
    "on_cb_choosePoint_stateChanged\0"
    "on_cb_fill_stateChanged\0"
    "on_cb_showGrid_stateChanged\0"
    "on_cb_setZ_stateChanged\0on_pb_default_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  124,    2, 0x06 /* Public */,
       3,    0,  127,    2, 0x06 /* Public */,
       4,    1,  128,    2, 0x06 /* Public */,
       5,    1,  131,    2, 0x06 /* Public */,
       6,    1,  134,    2, 0x06 /* Public */,
       7,    0,  137,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    1,  138,    2, 0x08 /* Private */,
       9,    0,  141,    2, 0x08 /* Private */,
      10,    1,  142,    2, 0x08 /* Private */,
      11,    1,  145,    2, 0x08 /* Private */,
      12,    1,  148,    2, 0x08 /* Private */,
      13,    0,  151,    2, 0x08 /* Private */,
      14,    1,  152,    2, 0x08 /* Private */,
      16,    1,  155,    2, 0x08 /* Private */,
      17,    0,  158,    2, 0x08 /* Private */,
      18,    0,  159,    2, 0x08 /* Private */,
      19,    0,  160,    2, 0x08 /* Private */,
      20,    1,  161,    2, 0x08 /* Private */,
      21,    1,  164,    2, 0x08 /* Private */,
      22,    1,  167,    2, 0x08 /* Private */,
      23,    1,  170,    2, 0x08 /* Private */,
      24,    0,  173,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signalMousePress((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 1: _t->signalMouseRelease(); break;
        case 2: _t->signalMouseMove((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 3: _t->signalWhell((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->signalAddPoins((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 5: _t->signalColor(); break;
        case 6: _t->slotMousePress((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 7: _t->slotMouseRelease(); break;
        case 8: _t->slotMouseMove((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 9: _t->slotWhell((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->slotAddPoints((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 11: _t->slotColor(); break;
        case 12: _t->on_cb_nAuto_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_sb_n_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_pb_clear_clicked(); break;
        case 15: _t->on_pb_saveAs_clicked(); break;
        case 16: _t->on_pb_update_clicked(); break;
        case 17: _t->on_cb_choosePoint_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_cb_fill_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->on_cb_showGrid_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_cb_setZ_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_pb_default_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(QPoint );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::signalMousePress)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::signalMouseRelease)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QPoint );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::signalMouseMove)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::signalWhell)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QPoint );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::signalAddPoins)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::signalColor)) {
                *result = 5;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::signalMousePress(QPoint _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::signalMouseRelease()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void MainWindow::signalMouseMove(QPoint _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::signalWhell(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MainWindow::signalAddPoins(QPoint _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MainWindow::signalColor()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
